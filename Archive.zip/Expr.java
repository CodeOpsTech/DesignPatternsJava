public class Expr { 
	public static void main(String []args) { 
		int a = 10, b = 20, c = 30; 
		int r = ((a * b) + c);
		System.out.println("" + r); 
	}
}

